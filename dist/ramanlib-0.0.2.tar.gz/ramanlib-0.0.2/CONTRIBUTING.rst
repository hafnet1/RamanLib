TODO: write a guide for contributing to this open source project

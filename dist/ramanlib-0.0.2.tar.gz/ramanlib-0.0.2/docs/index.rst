RamanLib Documentation
======================

.. toctree::
   :maxdepth: 2
   :caption: Quick Start

   usage/installation
   usage/quickstart

.. toctree::
   :maxdepth: 2
   :caption: Documentation

   api/index

.. toctree::
   :maxdepth: 2
   :caption: Guides

   guides/example_notebook

External Links
--------------
- `GitHub repository <https://github.com/hafnet1/ramanlib>`_

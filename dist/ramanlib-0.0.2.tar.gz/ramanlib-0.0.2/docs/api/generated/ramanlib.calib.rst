﻿ramanlib.calib
==============

.. automodule:: ramanlib.calib

   
   .. rubric:: Functions

   .. autosummary::
   
      fit_peak
      get_gsc_wn_shifts
      get_wn_shift
   
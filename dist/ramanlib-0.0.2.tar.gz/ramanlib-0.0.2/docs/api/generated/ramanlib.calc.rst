﻿ramanlib.calc
=============

.. automodule:: ramanlib.calc

   
   .. rubric:: Functions

   .. autosummary::
   
      mean_correlation_per_group
      mean_difference
      outliers_per_group
   
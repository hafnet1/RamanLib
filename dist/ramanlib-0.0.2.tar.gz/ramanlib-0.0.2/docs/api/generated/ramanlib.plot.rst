﻿ramanlib.plot
=============

.. automodule:: ramanlib.plot

   
   .. rubric:: Functions

   .. autosummary::
   
      baseline
      compare_baselines
      mean_correlation_per_group
      mean_difference
      mean_per_group
      n_baselines
      outliers_per_group
      random_per_group
   